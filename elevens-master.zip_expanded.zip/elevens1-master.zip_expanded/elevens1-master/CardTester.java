/**
 * This is a class that tests the Card class.
 */
public class CardTester {

	/**
	 * The main method in this class checks the Card operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		/* *** TO BE IMPLEMENTED IN ACTIVITY 1 *** */
		Card ace = new Card("ace", "spade", 1);
		Card jack = new Card("jack", "diamond", 11);
		Card queen = new Card("queen", "heart", 12);
		if (ace.matches(jack)) {
			System.out.println("match");
		} else {
			System.out.println("does not match");
		}
		System.out.println(ace.toString());
		System.out.println("rank is " + queen.rank());
		System.out.println("suit is " + queen.suit());
		System.out.println("point is " + queen.pointValue());
	}
}
